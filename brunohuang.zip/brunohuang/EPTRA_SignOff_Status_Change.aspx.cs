﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Linq;
using System.Web.Configuration;
using MySql.Data.MySqlClient;
using System.Text;
using System.Threading;


public partial class EPTRA_Lv_SignOff_Status_Change : System.Web.UI.Page
{
    public static int  global_RowIndex =0;
    public static string global_Ver_Name = "";
    public static string workno = "", chinesename = "", departname = "";
    [System.Web.Services.WebMethod]
    public static string[] GetCustomer(string prefix)
    {
        List<string> Customer = new List<string>();
        string strSQL2 = "select DISTINCT npiapp.New_Customer,npiimportdata.New_Customer,npimanual.New_Customer  from npiapp,npiimportdata,npimanual Where npiapp.New_Customer Like '" + prefix + "%' ";
        string strSQL = " select DISTINCT npiapp.New_Customer from npiapp where npiapp.New_Customer like '" + prefix + "%' union  select  npiimportdata.New_Customer from  npiimportdata where   npiimportdata.New_Customer like '" + prefix + "%' union select  npimanual.New_Customer from npimanual where npimanual.New_Customer like'" + prefix + "%'";

        clsMySQL db = new clsMySQL();
        foreach (DataRow dr in db.QueryDataSet(strSQL).Tables[0].Rows)
        {
            //customers.Add(string.Format("{0},{1}", dr["new_customer"], dr["new_device"]));
            Customer.Add(string.Format("{0}", dr["New_Customer"]));
        }
        return Customer.ToArray();
    }
    [System.Web.Services.WebMethod]
    public static string[] GetNewDevice(string prefix)
    {
        List<string> New_Device = new List<string>();
        string strSQL = " select DISTINCT npiapp.New_Device from npiapp where npiapp.New_Device like '" + prefix + "%' union  select  npiimportdata.New_Device from  npiimportdata where   npiimportdata.New_Device like '" + prefix + "%' union select  npimanual.New_Device from npimanual where npimanual.New_Device like'" + prefix + "%'";
        clsMySQL db = new clsMySQL();
        foreach (DataRow dr in db.QueryDataSet(strSQL).Tables[0].Rows)
        {
            //customers.Add(string.Format("{0},{1}", dr["new_customer"], dr["new_device"]));
            New_Device.Add(string.Format("{0}", dr["New_Device"]));
        }
        return New_Device.ToArray();
    }

    protected string rec_vername(string sql)
    {
        string ver_name = "";



        MySqlConnection MySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString);
        MySqlConn.Open();

        MySqlCommand MySqlCmd = new MySqlCommand(sql, MySqlConn);
        MySqlDataReader mydr = MySqlCmd.ExecuteReader();

        while (mydr.Read())
        {
            ver_name = (String)mydr["Ver_Name"];

        }
        mydr.Close();
        MySqlConn.Close();

        return ver_name;


    }


    protected void Page_Load(object sender, EventArgs e)
    {

         

        if(!Page.IsPostBack)
        {
            try
            {

                if (Session["Workno"].ToString() == "" || Session["chinesename"].ToString() == "" || Session["departname"].ToString() == "")
                {
                    string script = null;
                    script = "<script language = 'javascript'>alert('請重新登入！');parent.location.href='~/test/Login.aspx';</script>";
                    this.RegisterStartupScript("", script);
                    return;
                }
                else
                {
                    workno = Session["Workno"].ToString();
                    chinesename = Session["chinesename"].ToString();
                    departname = Session["departname"].ToString();
                }

            }
            catch (Exception ex)
            {
                string script = null;
                script = "<script language = 'javascript'>alert('請重新登入！');parent.location.href='Login.aspx';</script>";
                this.RegisterStartupScript("", script);
                return;
                lblError.Text = ex.ToString();
            }



            string sql_rec_npieptra_main_status = "select * from npieptraver_main AS T1,npitra_Signoff_Status AS T2 where T1.Ver_Status='Enable' and T2.TRA_Status='Enable' and Signoff_Case='EPTRA'";


            string Str_Ver = jude_lv_Signoff_Status(sql_rec_npieptra_main_status);
            String[] Str_Ver_Spilt = Str_Ver.Split('|');
            string ver_name = Str_Ver_Spilt[0];
            string ver_sta = Str_Ver_Spilt[1];
            string signoff_sta = Str_Ver_Spilt[2];
            string process = Str_Ver_Spilt[3];



            string sql_eptraver_main_sta = "select * from npitra_signoff_status where Ver_Name='" + ver_name + "' and TRA_Status='Enable' ";



            if (ver_name != "")
            {
                if (ver_sta == "Enable")
                {
                    Panel_gv1.Visible = true;
                    Panel_gv2.Visible = false;

                    clsMySQL db = new clsMySQL(); //Connection MySQL
                    clsMySQL.DBReply dr = db.QueryDS(sql_eptraver_main_sta);
                    gv_display_Lv_signoffdata.DataSource = dr.dsDataSet.Tables[0].DefaultView;
                    gv_display_Lv_signoffdata.DataBind();
                    db.Close();
                    set_sta_srt("gv1");
                    set_process_srt("gv1");
                }
                else if (ver_sta == "Disable")
                {
                    Panel_gv1.Visible = false;
                    Panel_gv2.Visible = false;
                    string strScript = string.Format("<script language='javascript'>alert('" + ver_name + "已被更改為Disable，請到TRA比對');</script>");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);
                }


            }
            else
            {
                string strScript = string.Format("<script language='javascript'>alert('" + ver_name + "還未送審!');</script>");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);
            }




        }






        //HttpContext.Current.Session["Workno"] = "test";
        //HttpContext.Current.Session["chinesename"] = "test";
        //HttpContext.Current.Session["departname"] = "OBU3Test";
        //workno = Session["Workno"].ToString();
        //chinesename = Session["chinesename"].ToString();
        //departname = Session["departname"].ToString();
    }

    protected string jude_lv_Signoff_Status(string sql)//撈出npieptra_lv_main_status中的ver_sta和signoff_sta的狀態
    {

        string ver_sta = "";
        string signoff_sta = "";
        string Ver_Name = "";
        string process = "";
        int i = 0;
        MySqlConnection MySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString);
        MySqlConn.Open();


        MySqlCommand MySqlCmd = new MySqlCommand(sql, MySqlConn);
        MySqlDataReader SelData = MySqlCmd.ExecuteReader();

        while (SelData.Read())
        {


           
             ver_sta = (String)SelData["Ver_Status"];
                signoff_sta = (String)SelData["Signoff_Step1_Status"];
                Ver_Name = (String)SelData["Ver_Name"];
                process = (String)SelData["Signoff_process"];
            



            i++;




        }

        SelData.Close();
        MySqlConn.Close();

        return Ver_Name + "|" + ver_sta + "|" + signoff_sta + "|" + process;


    }



    protected void Search_Lv_Click1(object sender, EventArgs e)
    {
        string str_eptraver_main = "select * from npieptraver_main where Ver_New_Customer = '" + Customer_TB.Text + "'and Ver_New_Device= '" + ND_TB.Text + "' and Ver_Status ='Enable'";

         

        string sql_rec_npieptra_main_status = "select * from npieptraver_main AS T1,npitra_Signoff_Status AS T2 where T1.Ver_New_Customer='" + Customer_TB.Text + "' and T1.Ver_New_Device='" + ND_TB.Text + "' and T1.Ver_Status='Enable' and T2.TRA_Status='Enable' and Signoff_Case='EPTRA'";


        string Str_Ver = jude_lv_Signoff_Status(sql_rec_npieptra_main_status);
        String[] Str_Ver_Spilt = Str_Ver.Split('|');
        string ver_name = Str_Ver_Spilt[0];
        string ver_sta = Str_Ver_Spilt[1];
        string signoff_sta = Str_Ver_Spilt[2];
        string process = Str_Ver_Spilt[3];


        string sql_eptraver_main_sta = "select * from npitra_signoff_status where Ver_Name='" + ver_name + "' and TRA_Status='Enable' ";


        if (Customer_TB.Text.Trim() != "" && ND_TB.Text.Trim() == "")
        {
            string strScript = string.Format("<script language='javascript'>alert('您沒輸入New_Device條件,請重新輸入!');</script>");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);
        }
        else if (Customer_TB.Text.Trim() == "" && ND_TB.Text.Trim() != "")
        {

            string strScript = string.Format("<script language='javascript'>alert('您沒輸入New_Customer條件,請重新輸入!');</script>");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);


        }
        else if (Customer_TB.Text.Trim() == "" && ND_TB.Text.Trim() == "")
        {

            string strScript = string.Format("<script language='javascript'>alert('您沒輸入New_Customer與New_Device條件,請重新輸入!');</script>");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);


        }
        else if (ver_name != "")
        {
            if(ver_sta=="Enable")
            {
                Panel_gv1.Visible = true;
                Panel_gv2.Visible = false;

                clsMySQL db = new clsMySQL(); //Connection MySQL
                clsMySQL.DBReply dr = db.QueryDS(sql_eptraver_main_sta);
                gv_display_Lv_signoffdata.DataSource = dr.dsDataSet.Tables[0].DefaultView;
                gv_display_Lv_signoffdata.DataBind();
                db.Close();
                set_sta_srt("gv1");
                set_process_srt("gv1");
            }
            else if (ver_sta=="Disable")
            {
                Panel_gv1.Visible = false;
                Panel_gv2.Visible = false;
                string strScript = string.Format("<script language='javascript'>alert('" + ver_name + "已被更改為Disable，請到TRA比對');</script>");
                Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);
            }


        }      
        else
        {
            string strScript = string.Format("<script language='javascript'>alert('"+ver_name+"還未送審!');</script>");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);
        }
    }

    protected string rec_main_process_srt(string sql)
    {

        string ret_str = "";
        MySqlConnection MySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString);
        MySqlConn.Open();


        MySqlCommand MySqlCmd = new MySqlCommand(sql, MySqlConn);
        MySqlDataReader SelData = MySqlCmd.ExecuteReader();

        while (SelData.Read())
        {


            ret_str = (String)SelData["Signoff_process"];


        }

        SelData.Close();
        MySqlConn.Close();


        return ret_str;
    }


    protected void set_process_srt(string sign)
    {
        if (sign == "gv1")
        {
            for (int i = 0; i < gv_display_Lv_signoffdata.Rows.Count; i++)
            {
                Label lab = (Label)gv_display_Lv_signoffdata.Rows[i].Cells[3].FindControl("Label_process");
                string Ver_name = gv_display_Lv_signoffdata.Rows[i].Cells[1].Text;
                string sql_sta = "select * from npitra_Signoff_Status where Ver_Name = '" + Ver_name + "'";
                string sta_process = rec_main_process_srt(sql_sta);
                if (sta_process == "Compare")
                {
                    lab.Text = "TRA比對";
                }
                else if (sta_process == "LV")
                {
                    lab.Text = "TRA_Lv設定";
                }
                else if (sta_process == "DOE")
                {
                    lab.Text = "DOE開案";
                }

            }
        }
        else
        {
            for (int i = 0; i < signoff_gv2.Rows.Count; i++)
            {
                Label lab = (Label)signoff_gv2.Rows[i].Cells[3].FindControl("Label_process");
                string Ver_name = signoff_gv2.Rows[i].Cells[0].Text;
                string sql_sta = "select * from npitra_Signoff_Status where Ver_Name = '" + Ver_name + "'";
                string sta_process = rec_main_process_srt(sql_sta);
                if (sta_process == "Compare")
                {
                    lab.Text = "TRA比對";
                }
                else if (sta_process == "LV")
                {
                    lab.Text = "TRA_Lv設定";
                }
                else if (sta_process == "DOE")
                {
                    lab.Text = "DOE開案";
                }

            }
        }
       
    }
    protected void set_sta_srt(string sign)/*將LV_Signoff_Status更改為,接受,拒絕,待簽中*/
    {


        if(sign =="gv1")
        {

            for (int i = 0; i < gv_display_Lv_signoffdata.Rows.Count; i++)
            {
                Label lab = (Label)gv_display_Lv_signoffdata.Rows[i].Cells[2].FindControl("Label_sta");
                string Ver_name = gv_display_Lv_signoffdata.Rows[i].Cells[1].Text;
                string sql_sta = "select * from npitra_signoff_status where Ver_Name = '" + Ver_name + "' and TRA_Status='Enable'";
                string sta_str = rec_main_status_srt(sql_sta);
                if (sta_str == "NA")
                {
                    lab.Text = "待簽中";
                }
                else if (sta_str == "Acc")
                {
                    lab.Text = "接受";
                }
                else if (sta_str == "Rej")
                {
                    lab.Text = "拒絕";
                }

            }
        

        }
        else
        {
            for (int i = 0; i < signoff_gv2.Rows.Count; i++)
            {
                Label lab = (Label)signoff_gv2.Rows[i].Cells[2].FindControl("Label_sta");
                string Ver_name = signoff_gv2.Rows[i].Cells[0].Text;
                string sql_sta = "select * from npitra_signoff_status where Ver_Name = '" + Ver_name + "'";
                string sta_str = rec_main_status_srt(sql_sta);
                if (sta_str == "NA")
                {
                    lab.Text = "待簽中";
                }
                else if (sta_str == "Acc")
                {
                    lab.Text = "接受";
                }
                else if (sta_str == "Rej")
                {
                    lab.Text = "拒絕";
                }

            }
        }








       


    }


    protected string rec_main_status_srt(string sql)
    {
        string sta = "";



        MySqlConnection MySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString);
        MySqlConn.Open();

        MySqlCommand MySqlCmd = new MySqlCommand(sql, MySqlConn);
        MySqlDataReader mydr = MySqlCmd.ExecuteReader();

        while (mydr.Read())
        {
            sta = (String)mydr["Signoff_Step1_Status"];

        }
        mydr.Close();
        MySqlConn.Close();

        return sta;


    }



    protected Boolean jude_Query_EPTRA(string sql, string vername)
    {
        string Lv_main_vername = "";
        clsMySQL db = new clsMySQL();

        MySqlConnection MySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString);
        MySqlConn.Open();

        MySqlCommand MySqlCmd = new MySqlCommand(sql, MySqlConn);
        MySqlDataReader mydr = MySqlCmd.ExecuteReader();

        while (mydr.Read())
        {
            Lv_main_vername = (String)mydr["Ver_Name"];
        }

        mydr.Close();
        MySqlConn.Close();

        if (Lv_main_vername == vername)
        {
            return true;
        }
        else
            return false;



    }





    protected void But_Change_Click(object sender, EventArgs e)
    {

        

        GridViewRow myRow = (GridViewRow)((Button)sender).NamingContainer;
        global_RowIndex = myRow.RowIndex;


        global_Ver_Name = gv_display_Lv_signoffdata.Rows[global_RowIndex].Cells[1].Text;


        string strScript = string.Format("<script language='javascript'>AddWork_acc();</script>");
        Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);


    }


    protected ArrayList receive_Signoff_info(string sql)//有signoff_status Table，所有資料
    {
        ArrayList signoff_info = new ArrayList();
      
        
        MySqlConnection MySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQL"].ConnectionString);
        MySqlConn.Open();


        MySqlCommand MySqlCmd = new MySqlCommand(sql, MySqlConn);
        MySqlDataReader SelData = MySqlCmd.ExecuteReader();

        while (SelData.Read())
        {
            
            
            for(int i=0;i<SelData.FieldCount;i++)
            {
                if (SelData.IsDBNull(i))
                    signoff_info.Add("");               
                else
                    signoff_info.Add(SelData.GetString(i));
                
            }



                    
        }

        SelData.Close();
        MySqlConn.Close();

        return signoff_info;


    }



    protected void up_signoff_status(int RowIndex, string com)
    {

        string ver = gv_display_Lv_signoffdata.Rows[RowIndex].Cells[1].Text;
        string sql_eptraver_main = "select * from npitra_signoff_status where Ver_Name='" + ver + "'";

            clsMySQL db = new clsMySQL();

            //ArrayList db_List_up_change_TRAStatus = new ArrayList();
          
            ArrayList list_signoff_info = new ArrayList();

            


        string sql_change_trastatus = string.Format("UPDATE npitra_signoff_status " +
                              " SET TRA_Status='{0}',UpdateName='{1}',UpdateTime=NOW(),Signoff_Status_Change_Command='{2}'" +
                              "where Ver_Name='{3}' and TRA_Status='Enable'",
                              "Disable",workno, com, ver);

        try
        {

            if (db.QueryExecuteNonQuery(sql_change_trastatus) == true)
            {

                Panel_gv1.Visible = false;
                Panel_gv2.Visible = true;

                clsMySQL.DBReply dr = db.QueryDS(sql_eptraver_main);
                signoff_gv2.DataSource = dr.dsDataSet.Tables[0].DefaultView;
                signoff_gv2.DataBind();
                set_sta_srt("gv2");
                set_process_srt("gv2");
            }
            else
            {

                lblError.Text += sql_change_trastatus + "<br />";
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }






        /*string ver_name = list_signoff_info[0].ToString();
        string ver_sta = list_signoff_info[2].ToString();
        string signoff_step1_sta = list_signoff_info[9].ToString();
        string signoff_case = list_signoff_info[18].ToString();
        string process = list_signoff_info[19].ToString();*/


        /*string Sql_his_sql_change_trastatus = string.Format("insert into npitra_his_signoff_Status" +
                    "(His_Record_Time,Ver_Name,Ver_No,TRA_Status,CreateName,CreateTime," +
                    "UpdateName,UpdateTime,His_Signoff_SendName,His_Signoff_SendTime," +
                    "His_Signoff_Step1_Status,His_Signoff_Step1_Name,His_Signoff_Step1_Time,His_Signoff_Step1_Command," +
                    "His_Signoff_Step2_Status,His_Signoff_Step2_Name,His_Signoff_Step2_Time,His_Signoff_Step2_Command," +
                    "Signoff_Status_Change_Command,His_Signoff_case,His_Signoff_process)values" +
                    "(NOW(),'{0}','{1}','{2}','{3}','{4}',"+
                    "'{5}','{6}','{7}','{8}','{9}','{10}',"+
                    "'{11}','{12}','{13}','{14}','{15}','{16}'," +
                    "'{17}','{18}','{19}')",
                    list_signoff_info[0].ToString(), list_signoff_info[1].ToString(), list_signoff_info[2].ToString(), list_signoff_info[3].ToString(),Convert.ToDateTime(list_signoff_info[4]),
                    list_signoff_info[5].ToString(), Convert.ToDateTime(list_signoff_info[6]), list_signoff_info[7].ToString(), Convert.ToDateTime(list_signoff_info[8]), list_signoff_info[9].ToString(),
                    list_signoff_info[10].ToString(), Convert.ToDateTime(list_signoff_info[11]), list_signoff_info[12].ToString(), list_signoff_info[13].ToString(), list_signoff_info[14].ToString(),
                    Convert.ToDateTime(list_signoff_info[15]), list_signoff_info[16].ToString(), list_signoff_info[17].ToString(), list_signoff_info[18].ToString(), list_signoff_info[19].ToString());
            */
        list_signoff_info = receive_Signoff_info(sql_eptraver_main);

        string Sql_his_sql_change_trastatus = string.Format("insert into npitra_his_signoff_Status" +
                   "(His_Record_Time,Ver_Name,Ver_No,TRA_Status,CreateName,CreateTime," +
                   "UpdateName,UpdateTime,His_Signoff_SendName,His_Signoff_SendTime," +
                   "His_Signoff_Step1_Status,His_Signoff_Step1_Name,His_Signoff_Step1_Time,His_Signoff_Step1_Command," +
                   "His_Signoff_Step2_Status,His_Signoff_Step2_Name,His_Signoff_Step2_Time,His_Signoff_Step2_Command," +
                   "His_Signoff_Status_Change_Command,His_Signoff_case,His_Signoff_process)values" +
                   "(NOW(),'{0}','{1}','{2}','{3}','{4}'," +
                   "'{5}','{6}','{7}','{8}','{9}','{10}'," +
                   "'{11}','{12}','{13}','{14}','{15}','{16}'," +
                   "'{17}','{18}','{19}')",
                   list_signoff_info[0].ToString(), list_signoff_info[1].ToString(), list_signoff_info[2].ToString(), list_signoff_info[3].ToString(), list_signoff_info[4].ToString(),
                   list_signoff_info[5].ToString(), list_signoff_info[6].ToString(), list_signoff_info[7].ToString(), list_signoff_info[8].ToString(), list_signoff_info[9].ToString(),
                   list_signoff_info[10].ToString(),list_signoff_info[11].ToString(), list_signoff_info[12].ToString(), list_signoff_info[13].ToString(), list_signoff_info[14].ToString(),
                   list_signoff_info[15].ToString(), list_signoff_info[16].ToString(), list_signoff_info[17].ToString(), list_signoff_info[18].ToString(), list_signoff_info[19].ToString());

       

        try
        {

            if (!db.QueryExecuteNonQuery(Sql_his_sql_change_trastatus))
            {
                lblError.Text += Sql_his_sql_change_trastatus + "<br />";
            }
                                 
        }
        catch (Exception ex)
        {
            throw ex;
        }

        db.Close();

    
    }


    protected void cmdFilter_Click(object sender, EventArgs e)
    {
        string str_command = hf_command_value.Value;



        up_signoff_status(global_RowIndex,str_command);
       
              

    }




}