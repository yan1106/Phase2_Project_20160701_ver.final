﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

public partial class Test_POPUP_Query : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void but1_Click(object sender, EventArgs e)
    {
        string strScript = "";
        string arydata = "";
        arydata = text1.Text+ "|" + text2.Text;
        strScript = "<script language='javascript'>Confirm('確定？','" + arydata + "');</script>";
        Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);

    }

    [System.Web.Services.WebMethod(EnableSession = true)]
    public static string CreateJob(string strConjData)
    {
        string strError = "";
        string[] strData = new string[1];
        strData = strConjData.Split('|');
        HttpContext.Current.Session["value1"] = strData[0];
        HttpContext.Current.Session["value2"] = strData[1];
        return strError;
    }
}