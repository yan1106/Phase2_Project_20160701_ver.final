﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.HtmlControls;

public partial class Test_POPUP_Test : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
        }
    }
    protected void cmdCreateJob_Click(object sender, EventArgs e)
    {
        string strScript = string.Format("<script language='javascript'>AddWork();</script>");
        Page.ClientScript.RegisterStartupScript(this.GetType(), "onload", strScript);
    }
    protected void cmdFilter_Click(object sender, EventArgs e)
    {
        lab1.Text = Session["value1"].ToString();
        lab2.Text = Session["value2"].ToString();
    }
}