﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.VisualBasic;
using System.Data;
using System.Diagnostics;

public partial class Test_Home : System.Web.UI.Page
{
    public string strUserCode;
    protected void Page_Load(object sender, EventArgs e)
    {

        
        //try
        //{

        //    if (Session["username"].ToString() == "" || Session["usercode"].ToString() == "")
        //    {
        //        string script = null;
        //        script = "<script language = 'javascript'>alert('請重新登入！');parent.location.href='~/test/Login.aspx';</script>";
        //        this.RegisterStartupScript("", script);
        //        return;
        //    }
        //    else
        //    {
        //        //lblError.Text = "User Code=" + Session["usercode"].ToString() + " ; UserName = " + Session["username"].ToString(); 
        //        strUserCode = "";
        //        strUserCode = Session["usercode"].ToString();
        //        //UserName.Text = "使用者 : " + Session["username"].ToString();
        //        MenuMain.Items[0].Text = "使用者:" + Session["chinesename"].ToString() + "| 單位:" + Session["departname"].ToString() ;

        //        //lblError.Text = MenuMain.Items.Count.ToString();
        //    }

        //}
        //catch (Exception ex)
        //{
        //    string script = null;
        //    script = "<script language = 'javascript'>alert('請重新登入！');parent.location.href='Login.aspx';</script>";
        //    this.RegisterStartupScript("", script);
        //    return;
        //    lblError.Text = ex.ToString();
        //}

    }
    protected void MenuMain_Load(object sender, EventArgs e)
    {
        //if (Convert.ToInt32(Session["userflag"]) < 3)
        //{
        //    MenuMain.Items[3].ChildItems[0].Selectable = false;
        //    //MenuMain.Items[3].ChildItems[1].Selectable = false;            
        //}        
    }
}